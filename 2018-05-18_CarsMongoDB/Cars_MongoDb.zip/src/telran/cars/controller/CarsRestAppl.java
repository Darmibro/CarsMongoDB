package telran.cars.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarsRestAppl {
public static void main(String[] args) {
	SpringApplication.run(CarsRestAppl.class, args); 
}
}
